

package com.HBuilder.integrate.wxapi;

import io.dcloud.feature.oauth.weixin.AbsWXCallbackActivity;

	public class WXEntryActivity extends AbsWXCallbackActivity{

}



