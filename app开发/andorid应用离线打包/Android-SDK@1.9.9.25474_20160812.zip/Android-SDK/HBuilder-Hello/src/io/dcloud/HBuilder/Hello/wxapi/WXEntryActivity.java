

package io.dcloud.HBuilder.Hello.wxapi;

import io.dcloud.feature.oauth.weixin.AbsWXCallbackActivity;

	public class WXEntryActivity extends AbsWXCallbackActivity{

}



