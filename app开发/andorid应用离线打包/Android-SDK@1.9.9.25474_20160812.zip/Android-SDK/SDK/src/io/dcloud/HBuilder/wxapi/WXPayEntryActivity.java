

package io.dcloud.HBuilder.wxapi;

import io.dcloud.feature.payment.weixin.AbsWXPayCallbackActivity;

public class WXPayEntryActivity extends AbsWXPayCallbackActivity{
	
}



