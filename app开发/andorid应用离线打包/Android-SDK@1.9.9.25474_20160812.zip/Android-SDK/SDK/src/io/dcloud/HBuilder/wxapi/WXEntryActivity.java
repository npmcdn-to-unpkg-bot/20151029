

package io.dcloud.HBuilder.wxapi;

import io.dcloud.feature.oauth.weixin.AbsWXCallbackActivity;

	public class WXEntryActivity extends AbsWXCallbackActivity{

}



